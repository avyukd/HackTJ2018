import React, { Component } from "react";
import { Card, Button } from "semantic-ui-react";
import moment from "moment";

import Layout from "components/Layout";
import contract from "ethereum/contract";

class DAppIndex extends Component {
  // modify to make some function call to your deployed contract
  static async getInitialProps() {
    //await contract.methods.giveRightToOwn(0x0bb4953654e8818305af72b1bbabcbb24c9b48b1);
    const authority = await contract.methods.authority().call();
    const owner = await contract.methods.owner().call();
    const buyer = await contract.methods.buyer().call();
    await contract.methods.giveRightToOwn(0x0bb4953654e8818305af72b1bbabcbb24c9b48b1).call();
    console.log(authority);
    console.log(owner);
    console.log(buyer);
    return {authority, owner, buyer};
  }

  renderAuctionInfo() {
    return (
      <Card
        header="Authority"
        description={
          "This authority is " +
          this.props.authority
        }
      />
    );
  }

  render() {
    return (
      <Layout>
        <h3>Auction</h3>
        {this.renderAuctionInfo()}
      </Layout>
    );
  }
}

export default DAppIndex;
