// import our web3 instance
import web3 from "./web3";
import Contract from "./build/House.json";

// get Contract instance
// replace <> with the address of your deployed Contract instance
// use web3 to get the contract instance
const instance = new web3.eth.Contract(
  JSON.parse(Contract.interface),
  "0x0226199e68cC1261F6968e7c680D918d31f9b173"
);

export default instance;
